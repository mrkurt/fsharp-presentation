#light
open System

(* What is the smallest number 
that is evenly divisible 
by all of the numbers from 1 to 20?
*)