﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSharpExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 7;
        }
    }
}
